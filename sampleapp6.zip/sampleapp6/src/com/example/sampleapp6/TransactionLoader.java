package com.example.sampleapp6;

import java.util.ArrayList;
import java.util.List;

import com.firstdata.firstapi.client.domain.v2.TransactionRequest;

public class TransactionLoader {

	//List<TransactionRequest> requests = new ArrayList<TransactionRequest>();
	public void LoadTransactions()
	{
		
	}
}
