package com.example.sampleapp6;



import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
//import org.springframework.beans.BeansException;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.web.client.RestTemplate;

import com.firstdata.firstapi.client.FirstAPIClientV2Helper;
//import com.firstdata.firstapi.client.FirstDataAPIClientV2Test;
import com.firstdata.firstapi.client.domain.TransactionType;
import com.firstdata.firstapi.client.domain.v2.Address;
import com.firstdata.firstapi.client.domain.v2.Card;
import com.firstdata.firstapi.client.domain.v2.TransactionRequest;
import com.firstdata.firstapi.client.domain.v2.TransactionResponse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


//@ContextConfiguration(locations={"classpath:/META-INF/spring/core-rest-client-v2-context.xml"})
public class MainActivity extends Activity {

	private static Context context;


    public void onCreate(){
        MainActivity.context = getApplicationContext();
        TextView text =  (TextView)findViewById(R.id.txt_rmsg);
        text.setText("authorizelevel3");
    }

    public static Context getAppContext() {
        return MainActivity.context;
    }

	//public static final Logger log= LoggerFactory.getLogger("SampleAPP6");
	
	//private RestTemplate restTemplate;
	//private FirstAPIClientV2Helper client;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void onButton1Clicked(View view)
	{
		Toast.makeText(getApplicationContext(), " Button 1 Clicked", Toast.LENGTH_SHORT).show();
		try
		{
			HttpClient httpclient = new DefaultHttpClient();
		    URI URL = new URI("https://api-cert.payeezy.com/v1");
			HttpResponse response = httpclient.execute(new HttpGet(URL ));
		    StatusLine statusLine = response.getStatusLine();
		    if(statusLine.getStatusCode() == HttpStatus.SC_OK){
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		        response.getEntity().writeTo(out);
		        String responseString = out.toString();
		        out.close();
		        //org.springframework.beans.BeansException b = new  BeansException();
		        //..more logic
		    } else {
		        //Closes the connection.
		        response.getEntity().getContent().close();
		        throw new IOException(statusLine.getReasonPhrase());
		    }
			}catch(Exception e)
			{
				Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
			}
	}
	
	public void onLogin1(View view)
	{
		/*
		URLClassLoader urlClassLoader;
		try {
			urlClassLoader = new URLClassLoader(new URL[]{new URL("file:///C:/nilesh/workspaceADT/app7/lib/org.apache.commons.codec.jar")});
		
			Class gsonClass = urlClassLoader.loadClass("org.apache.commons.codec.binary.Base64");  
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  */

		
		//this.getClass().getClassLoader();
		/*URL myurl1 = this.getClass().getClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\org.apache.commons.codec.jar");
		URL myurl2 = ClassLoader.getSystemClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\org.apache.commons.codec.jar");
        
		URLClassLoader child = new URLClassLoader(new URL[] { myurl1 }, MainActivity.class.getClassLoader());
		*/
		/*
		ClassLoader.getSystemClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\commons-codec-1.4.jar");
        //URLClassLoader child = new URLClassLoader (myJar.toURL(), this.getClass().getClassLoader());
//        org.apache.commons.codec.binary.Base64
        Class classToLoad = Class.forName ("org.apache.commons.codec.binary.Base64", true, child);
        Method method = classToLoad.getDeclaredMethod ("myMethod");
        Object instance = classToLoad.newInstance ();
        Object result = method.invoke (instance);*/
		Toast.makeText(getApplicationContext(), " Authorize Button 2 Clicked", Toast.LENGTH_SHORT).show();
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getPrimaryTransaction();
			TransactionResponse response = clientHelper.authorizeTransaction(trans);
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			//restTemplate = new RestTemplate();
			//assertNotNull("RESTTemplate is null:", restTemplate);
	        //assertNotNull("clietn is null:", client);
	        //TransactionResponse response=client.authorizeTransaction(getPrimaryTransaction());

	        //assertNotNull("Response is null ",response);
	        //assertNull("Error in response",response.getError());
	        //log.info("Transaction Tag:{} Transaction id:{}",response.getTransactionTag(),response.getTransactionId());
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
		Toast.makeText(getApplicationContext(), " + " , Toast.LENGTH_SHORT).show();
	}
	public void onLogin(View view)
	{
		try
		{
			/*
			String osNameString = System.getProperty("os.name");
			String osVersionString = System.getProperty("os.version");
			String osArchString = System.getProperty("os.arch");
			String jvNameString = System.getProperty("java.vm.name");
			String jvVersionString = System.getProperty("java.vm.version");
			String jvArchString = System.getProperty("java.vm.vendor");
			
			Toast.makeText(getApplicationContext(), osNameString, Toast.LENGTH_SHORT).show();
			Toast.makeText(getApplicationContext(), osVersionString, Toast.LENGTH_SHORT).show();
			Toast.makeText(getApplicationContext(), osArchString, Toast.LENGTH_SHORT).show();
			
			Toast.makeText(getApplicationContext(), jvNameString, Toast.LENGTH_SHORT).show();
			Toast.makeText(getApplicationContext(), jvVersionString, Toast.LENGTH_SHORT).show();
			Toast.makeText(getApplicationContext(), jvArchString, Toast.LENGTH_SHORT).show();
			*/
			
			/*
			RequestTask rTask5 = new RequestTask(getApplicationContext());
			rTask5.execute("AuthorizeAVS");
			//rTask5.wait();
			System.out.println("ValueLink authorize call end");
			*/
			
			TextView text =  (TextView)findViewById(R.id.txt_rmsg);
			//if(text.getText().toString() != "")
			String[] uri = new String[]{ text.getText().toString()};
			if(uri[0].toLowerCase().equalsIgnoreCase("authorizeavs"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizeavs");
				//rTask5.wait();
				System.out.println("authorizelevel2 authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizelevel2"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizelevel2");
				//rTask5.wait();
				System.out.println("authorizelevel2 authorize call end");
	    	}
	    	
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizelevel3"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizelevel3");
				//rTask5.wait();
				System.out.println("authorizelevel3 authorize call end");
	    	}
	    	
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizesplitshipments"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizesplitshipments");
				//rTask5.wait();
				System.out.println("authorizesplitshipments authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizetransarmor"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizetransarmor");
				//rTask5.wait();
				System.out.println("authorizetransarmor authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizenakedrefunds"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizenakedrefunds");
				//rTask5.wait();
				System.out.println("authorizetransarmor authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizesoftdescriptors"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizesoftdescriptors");
				//rTask5.wait();
				System.out.println("authorizetransarmor authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorizepaypal"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorizepaypal");
				//rTask5.wait();
				System.out.println("authorizetransarmor authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("authorize3ds"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("authorize3ds");
				//rTask5.wait();
				System.out.println("authorizetransarmor authorize call end");
	    	}
			
	    	if(uri[0].toLowerCase().equalsIgnoreCase("recurring"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("recurring");
				//rTask5.wait();
				System.out.println("authorizelevel3 authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("direct"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("direct");
				//rTask5.wait();
				System.out.println("direct authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("directw"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("directw");
				//rTask5.wait();
				System.out.println("direct authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("w"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("w");
				//rTask5.wait();
				System.out.println("direct authorize call end");
	    	}
	    	if(uri[0].toLowerCase().equalsIgnoreCase("test"))
	    	{
	    		RequestTask rTask5 = new RequestTask(getApplicationContext());
				rTask5.execute("test");
				//rTask5.wait();
				System.out.println("direct authorize call end");
	    	}
			/*
			RequestTask rTask5 = new RequestTask(getApplicationContext());
			rTask5.execute("AuthorizeValuelink");
			//rTask5.wait();
			System.out.println("ValueLink authorize call end");
			*/
			/*
			File dir = getApplicationContext().getFilesDir();
			
			
			TransactionRequestTask transactionRequestTask = new TransactionRequestTask(getApplicationContext());
			//transactionRequestTask.SetFilePath(dir + "/TestPayLoads.xls");
			transactionRequestTask.SetFilePath("TestPayLoads.xls");
			TextView text =  (TextView)findViewById(R.id.txt_rmsg);
			if(text.getText().toString() != "")
			{
				transactionRequestTask.SetFilePath(text.getText().toString());
			}
			transactionRequestTask.execute("All");
			*/
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	private boolean saveFile(Context context, String fileName) 
	{ 
		 
        // check if available and not read only 
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) { 
            Log.w("FileUtils", "Storage not available or read only"); 
            return false; 
        } 
        File DataDir = Environment.getDataDirectory();
        //File filepath = context.getDir("TestAppDir", Context.MODE_PRIVATE);
        //File filepath = context.getExternalFilesDir(null);
        // Create a path where we will place our List of objects on external storage 
        File file = new File(DataDir + "/TestPayloads.xls"); 
        PrintStream p = null; // declare a print stream object
        boolean success = false; 
 
        try { 
            OutputStream os = new FileOutputStream(file, true); 
            // Connect print stream to the output stream
            p = new PrintStream(os);
            p.println("This is a TEST");
            Log.w("FileUtils", "Writing file" + file); 
            success = true; 
        } catch (IOException e) { 
            Log.w("FileUtils", "Error writing " + file, e); 
        } catch (Exception e) { 
            Log.w("FileUtils", "Failed to save file", e); 
        } finally { 
            try { 
                if (null != p) 
                    p.close(); 
            } catch (Exception ex) { 
            } 
        } 
 
        return success; 
    } 
	private void readFile(Context context, String filename) { 
		 
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) 
        { 
            Log.w("FileUtils", "Storage not available or read only"); 
            return; 
        } 
 
        FileInputStream fis = null;
 
        try
        { 
            File file = new File(context.getExternalFilesDir(null), filename); 
            fis = new FileInputStream(file); 
            // Get the object of DataInputStream
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                Log.w("FileUtils", "File data: " + strLine);
                Toast.makeText(context, "File Data: " + strLine , Toast.LENGTH_SHORT).show();
            }
            in.close();
        } 
        catch (Exception ex) { 
            Log.e("FileUtils", "failed to load file", ex); 
        } 
        finally { 
            try {if (null != fis) fis.close();} catch (IOException ex) {} 
        } 
 
        return;
    } 
	public boolean isExternalStorageReadOnly() { 
        String extStorageState = Environment.getExternalStorageState(); 
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) { 
            return true; 
        } 
        return false; 
    } 
 
    public boolean isExternalStorageAvailable() { 
        String extStorageState = Environment.getExternalStorageState(); 
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) { 
            return true; 
        } 
        return false; 
    } 
	
	/*
	public Intent getDefaultViewIntent(Uri uri)
	{
	    PackageManager pm = this.getPackageManager();
	    Intent intent = new Intent(Intent.ACTION_VIEW);
	    // Let's probe the intent exactly in the same way as the VIEW action
	    String name=(new File(uri.getPath())).getName();
	    intent.setDataAndType(uri, this.getMimeType(name));
	    final List<ResolveInfo> lri = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
	    if(lri.size() > 0)
	        return intent;
	    return null;
	}*/
	public void onAuthorize(View view)
	{
		Toast.makeText(getApplicationContext(), " Authorize Clicked", Toast.LENGTH_SHORT).show();
		//CallAuthorize();
		
		try
		{
			RequestTask rTask = new RequestTask(getApplicationContext());
			rTask.execute("Authorize");
			System.out.println("first authorize call end");
			/*
			RequestTask rTask1 = new RequestTask(getApplicationContext());
			rTask1.execute("AuthorizeVisa");
			System.out.println("visa authorize call end");*/
			
			/*
			RequestTask rTask2 = new RequestTask(getApplicationContext());
			rTask2.execute("AuthorizeMastercard");
			//rTask2.wait();
			System.out.println("mastercard authorize call end");
				
			RequestTask rTask3 = new RequestTask(getApplicationContext());
			rTask3.execute("AuthorizeDiscover");
			//rTask3.wait();
			System.out.println("Discover authorize call end");
			
			
			RequestTask rTask4 = new RequestTask(getApplicationContext());
			rTask4.execute("AuthorizeAmex");
			//rTask4.wait();
			System.out.println("Amex authorize call end");
			
			
			RequestTask rTask5 = new RequestTask(getApplicationContext());
			rTask5.execute("AuthorizeValuelink");
			//rTask5.wait();
			System.out.println("ValueLink authorize call end");
			*/
			/*
			RequestTask rTask6 = new RequestTask(getApplicationContext());
			rTask6.execute("AuthorizeTelecheck");
			//rTask6.wait();
			System.out.println("Telecheck authorize call end");
			*/
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("authorize call end");
		//Toast.makeText(getApplicationContext(), " Authorize Completed", Toast.LENGTH_SHORT).show();
	}
	public void onPurchase(View view)
	{
		Toast.makeText(getApplicationContext(), " Purchase Clicked", Toast.LENGTH_SHORT).show();
		/*
		URLClassLoader urlClassLoader;
		try {
			urlClassLoader = new URLClassLoader(new URL[]{new URL("file:///C:/nilesh/workspaceADT/app7/lib/org.apache.commons.codec.jar")});
		
			Class gsonClass = urlClassLoader.loadClass("org.apache.commons.codec.binary.Base64");  
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  
		*/
		
		RequestTask rTask = new RequestTask(getApplicationContext());
		rTask.execute("Purchase");
		
		//Toast.makeText(getApplicationContext(), " Purchase Completed", Toast.LENGTH_SHORT).show();
		//CallPurchase();
	}
	
	public void onCapture(View view)
	{
		Toast.makeText(getApplicationContext(), " Capture Clicked", Toast.LENGTH_SHORT).show();
		//CallCapture();
		RequestTask rTask = new RequestTask(getApplicationContext());
		rTask.execute("Capture");
		//Toast.makeText(getApplicationContext(), " Capture Completed", Toast.LENGTH_SHORT).show();
	}
	
	public void onRefund(View view)
	{
		Toast.makeText(getApplicationContext(), " Refund Clicked", Toast.LENGTH_SHORT).show();
		//CallRefund();
		RequestTask rTask = new RequestTask(getApplicationContext());
		rTask.execute("Refund");
		//Toast.makeText(getApplicationContext(), " Refund Completed", Toast.LENGTH_SHORT).show();
	}
	
	public void onVoid(View view)
	{
		Toast.makeText(getApplicationContext(), " Void Clicked", Toast.LENGTH_SHORT).show();
		//CallVoid();
		RequestTask rTask = new RequestTask(getApplicationContext());
		rTask.execute("Void");
		//Toast.makeText(getApplicationContext(), " Void Completed", Toast.LENGTH_SHORT).show();
	}
	public void onValuelink(View view)
	{
		Toast.makeText(getApplicationContext(), " ValueLink Clicked", Toast.LENGTH_SHORT).show();
		try
		{
			
			RequestTask rTask5 = new RequestTask(getApplicationContext());
			rTask5.execute("Valuelink");
			//rTask5.wait();
			System.out.println("ValueLink call end");
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("valuelink call end");
		//Toast.makeText(getApplicationContext(), " Authorize Completed", Toast.LENGTH_SHORT).show();
	}
	public void onTelecheck(View view)
	{
		Toast.makeText(getApplicationContext(), " Telecheck Clicked", Toast.LENGTH_SHORT).show();
		try
		{
			
			RequestTask rTask5 = new RequestTask(getApplicationContext());
			rTask5.execute("Telecheck");
			//rTask5.wait();
			
			System.out.println("Telecheck call end");
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("telecheck call end");
		//Toast.makeText(getApplicationContext(), " Authorize Completed", Toast.LENGTH_SHORT).show();
	}
	private void CallAuthorize()
	{
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getPrimaryTransaction();
			TransactionResponse response = clientHelper.authorizeTransaction(trans);
			System.out.println("Response : " + response.toString());
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	private void CallPurchase()
	{
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getPrimaryTransaction();
			TransactionResponse response = clientHelper.purchaseTransaction(trans);
			System.out.println("Response : " + response.toString());
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	private void CallCapture()
	{
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getSecondaryTransaction();
			TransactionResponse response = clientHelper.captureTransaction(trans);
			System.out.println("Response : " + response.toString());
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	private void CallRefund()
	{
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getSecondaryTransaction();
			TransactionResponse response = clientHelper.refundTransaction(trans);
			System.out.println("Response : " + response.toString());
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	private void CallVoid()
	{
		try
		{
			FirstAPIClientV2Helper clientHelper = new FirstAPIClientV2Helper();
			String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
			String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
			String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
			String url = "https://api-cert.payeezy.com/v1";
			
			clientHelper.setAppId(appId);
			clientHelper.setSecuredSecret(secureId);
			clientHelper.setToken(token);
			clientHelper.setUrl(url);
			TransactionRequest trans = getSecondaryTransaction();
			TransactionResponse response = clientHelper.voidTransaction(trans);
			System.out.println("Response : " + response.toString());
			Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
			
		}catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), " Exception :" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	private TransactionRequest getPrimaryTransaction() {
        TransactionRequest request=new TransactionRequest();
        request.setAmount("1100");
        request.setCurrency("USD");
        request.setPaymentMethod("credit_card");
        request.setTransactionType(TransactionType.AUTHORIZE.getValue());
        Card card=new Card();
        card.setCvv("123");
        card.setExpiryDt("1220");
        card.setName("Test data ");
        card.setType("visa");
        card.setNumber("4788250000028291");
        request.setCard(card);
        Address address=new Address();
        request.setBilling(address);
        address.setState("NY");
        address.setAddressLine1("sss");
        address.setZip("11747");
        address.setCountry("US");

        return request;
    }
     
    private TransactionRequest getSecondaryTransaction() {
        TransactionRequest trans=new TransactionRequest();
        trans.setPaymentMethod("credit_card");
        trans.setAmount("1100.00");
        trans.setCurrency("USD");
        trans.setTransactionTag("45827000");
        trans.setTransactionId("ET162962");
        
        //trans.setTransactionTag("349990997");
        //trans.setTransactionId("07698G");
        return trans;
    }
    
}
