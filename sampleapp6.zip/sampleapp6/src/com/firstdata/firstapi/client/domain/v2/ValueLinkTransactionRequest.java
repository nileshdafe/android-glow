package com.firstdata.firstapi.client.domain.v2;

import org.codehaus.jackson.annotate.JsonProperty;

public class ValueLinkTransactionRequest {

	@JsonProperty("value_link")
	private ValueLinkCard giftcard;
	public ValueLinkCard getGiftcard() {
		return giftcard;
	}
	public void setGiftcard(ValueLinkCard giftcard) {
		this.giftcard = giftcard;
	}
}
