package com.firstdata.firstapi.client;



import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.http.protocol.ResponseServer;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.SerializationConfig.Feature;
//import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.runner.RunWith;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.restlet.engine.application.ApplicationHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;
//import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;

import android.app.Application;

import com.example.sampleapp6.MainActivity;
import com.example.sampleapp6.TransactionDataProvider;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.firstdata.firstapi.client.domain.TransactionType;
import com.firstdata.firstapi.client.domain.v2.Card;
import com.firstdata.firstapi.client.domain.v2.TransactionRequest;
import com.firstdata.firstapi.client.domain.v2.TransactionResponse;
import com.firstdata.firstapi.client.domain.v2.UserTransactionResponse;
//import com.google.gson.FieldNamingPolicy;
//import com.google.gson.Gson;
//import com.google.gson.JsonElement;

import dalvik.system.PathClassLoader;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations={"classpath:/META-INF/spring/core-rest-client-v2-context.xml"})
//@ContextConfiguration(locations={"classpath:/META-INF/spring/core-rest-client-v2-context.xml"})
public class FirstAPIClientV2Helper {
    
    //private static final Logger log=LoggerFactory.getLogger(FirstAPIClientV2Helper.class);
    
    @Autowired
    RestTemplate restTemplate;
    
    private String url;
    private String appId;
    private String securedSecret;
    private String token;
    
    public FirstAPIClientV2Helper()
    {
    	// Create a new RestTemplate instance
    	restTemplate = new RestTemplate();

    	// Add the Jackson and String message converters
    	restTemplate.getMessageConverters().add(new org.springframework.http.converter.xml.SourceHttpMessageConverter());
    	restTemplate.getMessageConverters().add(new org.springframework.http.converter.FormHttpMessageConverter());
    	org.springframework.http.converter.json.MappingJacksonHttpMessageConverter converter = new org.springframework.http.converter.json.MappingJacksonHttpMessageConverter();
    	converter.getObjectMapper().configure(Feature.WRITE_NULL_MAP_VALUES, false);
    	converter.getObjectMapper().configure(Feature.WRITE_NULL_PROPERTIES, false);
    	converter.getObjectMapper().configure(Feature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS, true);
    	
    	
    	restTemplate.getMessageConverters().add(converter);
    	//restTemplate.getMessageConverters().add(new org.springframework.http.converter.json.MappingJacksonHttpMessageConverter());
    	
    	//restTemplate.getMessageConverters().add(new org.springframework.http.converter.json.GsonHttpMessageConverter());
    	//restTemplate.getMessageConverters().add(new org.springframework.http.converter.json.GsonHttpMessageConverter(true));
    	//restTemplate.getMessageConverters().add(new org.springframework.http.converter.json.GsonHttpMessageConverter(new com.google.gson.Gson()));
    	
    	
    	restTemplate.setRequestFactory( new org.springframework.http.client.HttpComponentsClientHttpRequestFactory());
    	this.setUrl("https://api-cert.payeezy.com/v1");
    	this.setAppId("y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a");
    	this.setSecuredSecret("86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7");
    	this.setToken("fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6");
    	


    }
    
    
    public String getUrl() {
        return url;
    }

    
    public void setUrl(String url) {
        this.url = url;
    }

    
    public String getAppId() {
        return appId;
    }

    
    public void setAppId(String appId) {
        this.appId = appId;
    }

    
    public String getSecuredSecret() {
        return securedSecret;
    }

    
    public void setSecuredSecret(String secureId) {
        this.securedSecret = secureId;
    }
    
    

    
    public String getToken() {
        return token;
    }


    
    public void setToken(String token) {
        this.token = token;
    }


/*    private String getValue(String value){
        return new StringBuilder().append("\"").append(value).append("\"").toString();
    }
    */
    private static final String NONCE="nonce";
    
    public static final String APIKEY="apikey";
    public static final String APISECRET="pzsecret";
    public static final String TOKEN="token";
    public static final String TIMESTAMP="timestamp";
    public static final String AUTHORIZE="Authorization";
    public static final String PAYLOAD="payload";
    public static final String OVERRIDE="override";
    
    private Map<String,String> getSecurityKeys(String appId,String secureId,String payLoad) throws Exception{

        Map<String,String> returnMap=new HashMap<String,String>();
        long nonce;
        try {
            
            nonce = Math.abs(SecureRandom.getInstance("SHA1PRNG").nextLong());
            //String logMessage = String.format("SecureRandom nonce:{}",nonce);
            //System.out.println(logMessage);
            //log.debug("SecureRandom nonce:{}",nonce);
            MessageLogger.logMessage(String.format("SecureRandom nonce:{}",nonce));
            
            returnMap.put(NONCE, Long.toString(nonce));
            returnMap.put(APIKEY, this.appId);
            returnMap.put(TIMESTAMP, Long.toString(System.currentTimeMillis()));
            returnMap.put(TOKEN, this.token);
            returnMap.put(APISECRET, this.securedSecret);
            returnMap.put(PAYLOAD, payLoad);
            returnMap.put(AUTHORIZE, getMacValue(returnMap));
            return returnMap;
            
        } catch (NoSuchAlgorithmException e) {
            //log.error(e.getMessage(),e);
            MessageLogger.logMessage(e.getMessage());
            throw new RuntimeException(e.getMessage(),e);
        }       
    }
    
    public String getMacValue(Map<String,String> data) throws Exception{
        Mac mac=Mac.getInstance("HmacSHA256");
        String apiSecret= data.get(APISECRET);
        //log.debug("API_SECRET:{}",apiSecret);
        MessageLogger.logMessage(String.format("API_SECRET:{}",apiSecret));
        SecretKeySpec secret_key = new SecretKeySpec(apiSecret.getBytes(), "HmacSHA256");
        mac.init(secret_key);
        StringBuilder buff=new StringBuilder();
        buff.append(data.get(APIKEY))
        .append(data.get(NONCE))
        .append(data.get(TIMESTAMP));
        if(data.get(TOKEN)!=null)
            buff.append(data.get(TOKEN));
        if(data.get(PAYLOAD)!=null)
            buff.append(data.get(PAYLOAD));
        String bufferData = buff.toString();
        //log.info(buff.toString());
        //MessageLogger.logMessage(String.format(buff.toString()));
        MessageLogger.logMessage(String.format(bufferData));
        //byte[] macHash=mac.doFinal(buff.toString().getBytes("UTF-8"));
        byte[] macHash=mac.doFinal(bufferData.getBytes("UTF-8"));
        //log.info("MacHAsh:{}",Arrays.toString( macHash));
        MessageLogger.logMessage(Integer.toString(macHash.length));
        MessageLogger.logMessage(String.format("MacHAsh:{}",Arrays.toString( macHash)));
                
        //URLClassLoader urlClassLoader;
		//try 
		//{
			//byte[] bs = android.util.Base64.encode("foobar".getBytes(), android.util.Base64.NO_WRAP);
			//byte[] bs2 = android.util.Base64.encode(toHex(macHash), android.util.Base64.NO_WRAP);
			
			
			//ClassLoader cl = FirstAPIClientV2Helper.class.getClassLoader();
			 /*PathClassLoader pcl = (PathClassLoader)cl.getSystemClassLoader();
			 String p1 = pcl.findLibrary("org.apache.commons.codec.jar");
			 
			 String p2 = pcl.findLibrary("commons-codec-1.10.jar");
			 //System.out.println(p1);
			 //System.out.println(p2);*/
			 
			/*
			 URLClassLoader ucl = (URLClassLoader)cl.getSystemClassLoader();
			 
			 URL[] urls = ucl.getURLs();
			 for(int i=0;i<urls.length;i++)
			 {
				 System.out.println(urls[i].getPath());
			 }
			*/
			//ClassLoader.getSystemClassLoader().getResourceAsStream("file:///C:/images/LHC.bmp");
			
			//System.out.println( .getProtectionDomain().getCodeSource().getLocation().getPath());
			//urlClassLoader = new URLClassLoader(new URL[]{new URL("file:///C:/nilesh/workspaceADT/app7/lib/org.apache.commons.codec.jar")});
			
			//URLClassLoader urlClassLoader = new URLClassLoader(new URL[]{new URL("file:///C:/nilesh/workspaceADT/app7/lib/commons-codec-1.10.jar")});
			/*
			urlClassLoader = new URLClassLoader(new URL[]{new URL("file:///C:/nilesh/workspaceADT/app7/lib/commons-codec-1.10.jar")});

	        Class gsonClass = urlClassLoader.loadClass("org.apache.commons.codec.binary.Base64");  
	        String testStr=Base64.encodeBase64String(new byte[]{0,1,0,1});
	        byte[] bytes = toHex(macHash);
	        */
			//urlClassLoader = new URLClassLoader(new URL[]{new URL("org.apache.commons.codec.jar")});
		
			//Class gsonClass = urlClassLoader.loadClass("org.apache.commons.codec.binary.Base64");
			
			
		//} catch (Exception e1) {
			// TODO Auto-generated catch block
		//	e1.printStackTrace();
		//}  
        
        //String s = ClassLoader.getSystemClassLoader().getResource(resName)
        //ClassLoader.getSystemClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\org.apache.commons.codec.jar");
        //URL myurl = MainActivity.class.getClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\org.apache.commons.codec.jar");
        //ClassLoader.getSystemClassLoader().getResource("C:\\nilesh\\workspaceADT\\sampleapp6\\lib\\commons-codec-1.4.jar");
        //System.out.println(new Base64().getClass().getProtectionDomain().getCodeSource().getLocation());
        
		//String authorizeString=Base64.encodeBase64String(toHex(macHash));
		
		String authorizeString=android.util.Base64.encodeToString(toHex(macHash), android.util.Base64.NO_WRAP);
        
        //log.info("Authorize: {}",authorizeString);
        MessageLogger.logMessage(String.format("Authorize: {}",authorizeString));
        return authorizeString;
}
    
    public byte[] toHex(byte[] arr) {
    	MessageLogger.logMessage(Integer.toString(arr.length));
        //String hex= new String(Hex.encodeHexString(arr));
        String hex= byteArrayToHex(arr);
        //log.info("Apache common value:{}" , hex);
        MessageLogger.logMessage(String.format("Apache common value:{}" , hex));
        return hex.getBytes();
    }
    
    public static String byteArrayToHex(byte[] a) {
    	   StringBuilder sb = new StringBuilder(a.length * 2);
    	   for(byte b: a)
    	      sb.append(String.format("%02x", b & 0xff));
    	   return sb.toString();
    	}
    
    private HttpHeaders getHttpHeader(String appId,String securityKey,String payload ) throws Exception{
        Map<String,String> encriptedKey=getSecurityKeys(appId, securityKey,payload);
        HttpHeaders header=new HttpHeaders();
        Iterator<String> iter=encriptedKey.keySet().iterator();
        while(iter.hasNext()) {
            String key=iter.next();
            if(PAYLOAD.equals(key))
                continue;
            header.add(key, encriptedKey.get(key));
        }
        //header.add("User-Agent", System.getProperty("http.agent"));
        //header.add("User-Agent", "Mozilla/5.0 ( compatible ) ");
        header.add("User-Agent", "Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30");

        /*
        if(request.getHeaders().containsKey("User-Agent"))
        {
        	//request.getHeaders().set("User-Agent", System.getProperty("http.agent"));
        	request.getHeaders().set("User-Agent", "Mozilla/5.0 ( compatible ) ");
        }
        if(!request.getHeaders().containsKey("User-Agent"))
        {
        	//request.getHeaders().add("User-Agent", System.getProperty("http.agent"));
        	request.getHeaders().add("User-Agent", "Mozilla/5.0 ( compatible ) ");
        }
       */
        return header;
    }
    public String getJSONObject(Object data) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        OutputStream stream = new BufferedOutputStream(byteStream);
        JsonGenerator jsonGenerator =
            objectMapper.getJsonFactory().createJsonGenerator(stream,
                                                              JsonEncoding.UTF8);
        //mapper.getSerializationConfig();
        SerializationConfig s = objectMapper.getSerializationConfig();
        
        objectMapper.configure(Feature.WRITE_NULL_MAP_VALUES, false);
        //objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.AUTO_DETECT_FIELDS,true); 
        //objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.AUTO_DETECT_GETTERS,false); 
        //objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.CAN_OVERRIDE_ACCESS_MODIFIERS,true); 
        objectMapper.getSerializationConfig().setSerializationInclusion(org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion.NON_NULL); 
        //objectMapper.setVisibilityChecker(new VisibilityChecker.Std(JsonAutoDetect.Visibility.NONE,JsonAutoDetect.Visibility.NONE,JsonAutoDetect.Visibility.NONE,JsonAutoDetect.Visibility.NONE,JsonAutoDetect.Visibility.ANY)); 
        objectMapper.getDeserializationConfig().set(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.getDeserializationConfig().set(DeserializationConfig.Feature.FAIL_ON_NULL_FOR_PRIMITIVES, true);
        //objectMapper.getDeserializationConfig().set(DeserializationConfig.Feature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, false);
        
        objectMapper.writeValue(jsonGenerator, data);
        // mapper.writeValue(stream, payload);
        stream.flush();
        return new String(byteStream.toByteArray());
    }
    
    public UserTransactionResponse getJSONResponse(Object data) throws IOException {
    	ObjectMapper objectMapper = new ObjectMapper();
        
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        OutputStream stream = new BufferedOutputStream(byteStream);
        JsonGenerator jsonGenerator =
            objectMapper.getJsonFactory().createJsonGenerator(stream,
                                                              JsonEncoding.UTF8);
        objectMapper.writeValue(jsonGenerator, data);
        stream.flush();
        byte[] bytes = byteStream.toByteArray();
        
        com.fasterxml.jackson.databind.ObjectMapper fasterObjectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
        ByteArrayInputStream byteInputStream = new ByteArrayInputStream(bytes);
        java.io.InputStream inputStream = new java.io.BufferedInputStream(byteInputStream);
        JsonParser jsonParser = fasterObjectMapper.getJsonFactory().createJsonParser(inputStream);
        UserTransactionResponse utr = new UserTransactionResponse();
        utr = jsonParser.readValueAs(UserTransactionResponse.class );
        stream.flush();
        UserTransactionResponse res = fasterObjectMapper.convertValue(data, UserTransactionResponse.class);
 
        return res;
    }
    
    public UserTransactionResponse GetTransactionResponse(String responseMessage)
    {
    	String responseString = responseMessage;
    	UserTransactionResponse  transResponse = new UserTransactionResponse();
    	TransactionResponse response = new TransactionResponse();
    	Card card = new Card();
    	response.setCard(card);
    	transResponse.setBody(response);
    	
    	String[] strArray =  responseString.split(",");
    	
    	int start = responseString.indexOf("<") ;
    	int end = responseString.indexOf(",") ;
    	String resCode = responseString.substring(start, end);
    	if(resCode.startsWith("<"))
    	{
    		resCode = resCode.replaceFirst("<", "");
    	}
    	String[] codes = resCode.split(" ");
    	transResponse.setResponseCode(codes[0]);
    	transResponse.setResponseMessage(codes[1]);
    	
    	end = responseString.lastIndexOf(",");
    	responseString = responseString.substring(start, end);
    	/*
    	start = responseString.indexOf("method");
    	end = responseString.indexOf("," , start);
    	String subString = responseString.substring(start+1, end);
    	String[] vals = subString.split(":");
    	
    	
    	if(values[0] == "method")
		{
			//transResponse.getBody().setMethod(values[1]); ;
			transResponse.setMethod(values[1]); ;
		}
    	*/
    	
    	for(int i=0;i<strArray.length;i++)
    	{
    		try
    		{
	    		if(strArray[i] != null)
	    		{
	    			strArray[i] = strArray[i].trim();
		    		if(strArray[i].startsWith("{") )
		    		{
		    			strArray[i] = strArray[i].replace("{", "");
		    		}
		    		if(strArray[i].endsWith("}") )
		    		{
		    			strArray[i] = strArray[i].replace("}", "");
		    		}
		    		String[] values =  strArray[i].split("=");
		    		if(values.length>1)
		    		{
			    		if(values[1] == null)
			    		{
			    			continue;
			    		}
			    		values[0] = values[0].trim();
			    		values[1] = values[1].trim();
			    		if(values[0] != null)
			    		{
			    			if(values[0] == "method")
				    		{
				    			//transResponse.getBody().setMethod(values[1]); ;
				    			transResponse.setMethod(values[1]); ;
				    		}
				    		
				    		if(values[0] == "transaction_status")
				    		{
				    			//transResponse.getBody().setTransactionStatus(values[1]); ;
				    			transResponse.setTransactionStatus(values[1]); ;
				    		}
				    		if(values[0] == "validation_status")
				    		{
				    			//transResponse.getBody().setValidationStatus(values[1]);
				    			transResponse.setValidationStatus(values[1]);
				    		}
				    		if(values[0] == "transaction_type")
				    		{
				    			//transResponse.getBody().setTransactionType(values[1]);
				    			transResponse.setTransactionType(values[1]);
				    		}
				    		if(values[0] == "transaction_id")
				    		{
				    			//transResponse.getBody().setTransactionId(values[1]);
				    			transResponse.setTransactionId(values[1]);
				    		}
				    		if(values[0] == "transaction_tag")
				    		{
				    			//transResponse.getBody().setTransactionTag(values[1]);
				    			transResponse.setTransactionTag(values[1]);
				    		}
				    		
				    		if(values[0] == "amount")
				    		{
				    			//transResponse.getBody().setAmount(values[1]); 
				    			transResponse.setAmount(values[1]);
				    		}
				    		if(values[0] == "cardholder_name")
				    		{
				    			//transResponse.getBody().getCard().setName(values[1]);
				    			transResponse.getCard().setName(values[1]);
				    		}
				    		if(values[0] == "card_number")
				    		{
				    			//transResponse.getBody().getCard().setNumber(values[1]);
				    			transResponse.getCard().setNumber(values[1]);
				    		}
				    		if(values[0] == "exp_date")
				    		{
				    			//transResponse.getBody().getCard().setExpiryDt(values[1]); 
				    			transResponse.getCard().setExpiryDt(values[1]);
				    		}
				    		if(values[0] == "amount")
				    		{
				    			//transResponse.getBody().setAmount(values[1]);
				    			transResponse.setAmount(values[1]);
				    		}
				    		
				    		if(values[0] == "bank_resp_code")
				    		{
				    			//transResponse.getBody().setBankRespCode(values[1]);
				    			transResponse.setBankRespCode(values[1]);
				    		}
				    		if(values[0] == "bank_message")
				    		{
				    			//transResponse.getBody().setBankMessage(values[1]);
				    			transResponse.setBankMessage(values[1]);
				    		}
				    		if(values[0] == "gateway_resp_code")
				    		{
				    			//transResponse.getBody().setGatewayRespCode(values[1]);
				    			transResponse.setGatewayRespCode(values[1]);
				    		}
				    		if(values[0] == "gateway_message")
				    		{
				    			//transResponse.getBody().setGatewayMessage(values[1]);
				    			transResponse.setGatewayMessage(values[1]);
				    		}
				    		if(values[0] == "correlation_id")
				    		{
				    			//transResponse.getBody().setCorrelationID(values[1]); 
				    			transResponse.setCorrelationID(values[1]);
				    		}
				    		if(values[0] == "valuelink")
				    		{
				    			//transResponse.getBody().setCorrelationID(values[1]); 
				    			card.setName(values[1]);
				    		}
			    		}
		    		}
	    		}
    		}
    		catch(Exception e)
    		{
    			System.out.println(e.getMessage());
    		}
    	}
    	transResponse.setBody(response);
    	return transResponse;
    }
    
    private TransactionResponse doPrimaryTransaction(TransactionRequest trans) throws Exception{
    	if((trans.getPaymentMethod().toLowerCase() != "valuelink") && (trans.getPaymentMethod().toLowerCase() != "token")  && (trans.getPaymentMethod().toLowerCase() != "3ds"))
    	{
	        Assert.notNull(trans.getCard().getName(),"Card holder name is empty");

	        Assert.notNull(trans.getCard().getExpiryDt(),"Card Expiry date is not present");
	        Assert.notNull(trans.getCard().getNumber(),"Card number is not present");
    	}
        
        if(trans.getPaymentMethod().toLowerCase() == "valuelink")
    	{
        	Assert.notNull(trans.getGiftcard().getCc_number(),"Value Link Card number is not present");
    	}
        if((trans.getTransactionType().toLowerCase() != "deactivate"))
        {
        	Assert.notNull(trans.getAmount(),"Amount is not present");
        }
        Assert.notNull(trans.getTransactionType(),"Transaction type is not present");
    
        if((trans.getEciindicator() == "5") && (trans.getTransactionType().toLowerCase().equalsIgnoreCase("void")))
        {
        	trans.setBilling(null);
        	trans.setEciindicator(null);
        }
        //org.codehaus.jackson.map.ObjectMapper objectMapper = new org.codehaus.jackson.map.ObjectMapper();
        //com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
        //objectMapper.setconfigure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //objectMapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String url=this.url+"/transactions";
        String payload=getJSONObject(trans);
        HttpEntity<TransactionRequest> request=new HttpEntity<TransactionRequest>(trans,getHttpHeader(this.appId, this.securedSecret,payload));
        //ResponseEntity<TransactionResponse> response= restTemplate.exchange(url, HttpMethod.POST, request, TransactionResponse.class);
        //UserTransactionResponse responseObject= restTemplate.exchange(url, HttpMethod.POST, request, UserTransactionResponse.class);
        //ResponseEntity<UserTransactionResponse> response= restTemplate.exchange(url, HttpMethod.POST, request, UserTransactionResponse.class);
        //naked void
        //String transId = trans.getTransactionId(); 
        /*if(trans.getTransactionType().toLowerCase().equals( TransactionType.VOID.name().toLowerCase()))
        {
        	//naked void
        	trans.setTransactionId(null);
        	request.getBody().setTransactionId(null);
        }*/
        //ResponseEntity<TransactionResponse[]> response= restTemplate.exchange(url, HttpMethod.POST, request, TransactionResponse[].class);
        //request.getHeaders().setUserAgent(System.getProperty("http.agent"));
       
        //request.getHeaders().setUserAgent("Mozilla/5.0 ( compatible ) ");
        ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.POST, request, Object.class);
        System.out.println(response.toString());
        String resString = response.toString();
        UserTransactionResponse uresponseStr = GetTransactionResponse(resString);
        uresponseStr.setResponseString(resString);
        TransactionResponse responseStr = (TransactionResponse)uresponseStr;
        //ResponseEntity<TransactionResponse> response= (ResponseEntity<TransactionResponse>)responseObject;
        //ResponseEntity<HashMap> response= restTemplate.exchange(url, HttpMethod.POST, request, HashMap.class);
        //return doTransaction(trans,credentials);
        //Object r = response.getBody();
        //com.google.gson.GsonBuilder gsonBuilder = new com.google.gson.GsonBuilder();
        //Gson gson =  gsonBuilder.disableHtmlEscaping().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).setPrettyPrinting().serializeNulls().create();;
        //com.google.gson.Gson gson = gsonBuilder.disableHtmlEscaping().serializeNulls().create();
        //String jsonstring= response.toString();
        //TransactionResponse tr = gson.fromJson(jsonstring, TransactionResponse.class);
        //String sg = gson.toJson(response, TransactionResponse.class);
        
        //com.google.gson.JsonParser parser = new com.google.gson.JsonParser();
        
        
        //JsonElement element = parser.parse(r.toString());
        
        //UserTransactionResponse r1 = getJSONResponse(response);
        
        //TransactionResponse responseBody = (TransactionResponse)response.getBody().getBody();
        //TransactionResponse responseBody = (TransactionResponse)response.getBody();
        //TransactionResponse responseBody = (TransactionResponse)r;
        //return responseBody;
        return uresponseStr;
//        return null;
    
    }
    
    private TransactionResponse doGetPrimaryTransaction(TransactionRequest trans) throws Exception{
    	if(trans.getPaymentMethod().toLowerCase() != "valuelink")
    	{
	        Assert.notNull(trans.getCard().getName(),"Card holder name is empty");
	        Assert.notNull(trans.getCard().getExpiryDt(),"Card Expiry date is not present");
	        Assert.notNull(trans.getCard().getNumber(),"Card number is not present");
    	}
        
        if(trans.getPaymentMethod().toLowerCase() == "valuelink")
    	{
        	Assert.notNull(trans.getGiftcard().getCc_number(),"Value Link Card number is not present");
    	}
        
        Assert.notNull(trans.getAmount(),"Amount is not present");
        Assert.notNull(trans.getTransactionType(),"Transaction type is not present");
    
        String url=this.url+"/transactions";
        String payload=getJSONObject(trans);
        HttpEntity<TransactionRequest> request=new HttpEntity<TransactionRequest>(trans,getHttpHeader(this.appId, this.securedSecret,payload));
        //request.getHeaders().setUserAgent(System.getProperty("http.agent"));
        ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.GET, request, Object.class);
        System.out.println(response.toString());
        String resString = response.toString();
        UserTransactionResponse uresponseStr = GetTransactionResponse(resString);
        uresponseStr.setResponseString(resString);
        TransactionResponse responseStr = (TransactionResponse)uresponseStr;
        return uresponseStr;
    
    }
    
    private TransactionResponse doSecondaryTransaction(TransactionRequest trans) throws Exception{
            Assert.notNull(trans.getTransactionTag(),"Transaction Tag is not present");
            Assert.notNull(trans.getId(),"Id is not present"); 
            Assert.notNull(trans.getTransactionType(),"Transaction type is not present");
            String url=this.url+"/transactions/{id}";
            String payload=getJSONObject(trans);
            
            HttpEntity<TransactionRequest> request=new HttpEntity<TransactionRequest>(trans,getHttpHeader(this.appId, this.securedSecret,payload));
            //ResponseEntity<TransactionResponse> response= restTemplate.exchange(url, HttpMethod.POST, request, TransactionResponse.class,trans.getTransactionId());
            //ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.POST, request, Object.class,trans.getTransactionId());
            //request.getHeaders().setUserAgent(System.getProperty("http.agent"));
            ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.POST, request, Object.class,trans.getId());
            System.out.println(response.toString());
            String resString = response.toString();
            UserTransactionResponse uresponseStr = GetTransactionResponse(resString);
            uresponseStr.setResponseString(resString);
            TransactionResponse responseStr = (TransactionResponse)uresponseStr;
            //        return doTransaction(trans,credentials);
            //return response.getBody();
            return uresponseStr;
//           return null;
        }
    
    private TransactionResponse doSecondaryTransactionSplit(TransactionRequest trans) throws Exception{
        Assert.notNull(trans.getTransactionTag(),"Transaction Tag is not present");
        //Assert.notNull(trans.getTransactionId(),"Id is not present"); 
        Assert.notNull(trans.getId(),"Id is not present"); 
        Assert.notNull(trans.getTransactionType(),"Transaction type is not present");
        String url=this.url+"/transactions/{id}";
        String payload=getJSONObject(trans);
        HttpEntity<TransactionRequest> request=new HttpEntity<TransactionRequest>(trans,getHttpHeader(this.appId, this.securedSecret,payload));
        //ResponseEntity<TransactionResponse> response= restTemplate.exchange(url, HttpMethod.POST, request, TransactionResponse.class,trans.getTransactionId());
        //ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.POST, request, Object.class,trans.getTransactionId());
        //client.getParams().setParameter(CoreProtocolPNames.USER_AGENT, System.getProperty("http.agent"));
        //request.getHeaders().setUserAgent(System.getProperty("http.agent"));
        ResponseEntity<Object> response= restTemplate.exchange(url, HttpMethod.POST, request, Object.class,trans.getId());
        System.out.println(response.toString());
        String resString = response.toString();
        UserTransactionResponse uresponseStr = GetTransactionResponse(resString);
        uresponseStr.setResponseString(resString);
        TransactionResponse responseStr = (TransactionResponse)uresponseStr;
        //        return doTransaction(trans,credentials);
        //return response.getBody();
        return uresponseStr;
//       return null;
    }
    
    
    
    public TransactionResponse purchaseTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.PURCHASE.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse authorizeTransaction(TransactionRequest trans) throws Exception{
        trans.setTransactionType(TransactionType.AUTHORIZE.name());
        return doPrimaryTransaction(trans);
    }
    public TransactionResponse captureTransaction(TransactionRequest trans)throws Exception{
        trans.setTransactionType(TransactionType.CAPTURE.name().toLowerCase());
        
        return doSecondaryTransaction(trans);
    }
    public TransactionResponse refundTransaction(TransactionRequest trans)throws Exception{
        trans.setTransactionType(TransactionType.REFUND.name());
        return doSecondaryTransaction(trans);
    }
    public TransactionResponse voidTransaction(TransactionRequest trans)throws Exception{
        trans.setTransactionType(TransactionType.VOID.name());      
        return doSecondaryTransaction(trans);
    }
    
    public TransactionResponse nakedVoidTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.VOID.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse nakedRefundTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.REFUND.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse CashoutTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.CASHOUT.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse ReloadTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.RELOAD.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse PartialPurchaseTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.PURCHASE.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse ActivationTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.ACTIVATION.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse DeactivationTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.DEACTIVATION.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse BalanceInquiryTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.BALANCEENQUIRY.name());
        return doPrimaryTransaction(trans);
    }
    
    public TransactionResponse SplitTransaction(TransactionRequest trans) throws Exception{
        
        trans.setTransactionType(TransactionType.SPLIT.name());
        return doSecondaryTransaction(trans);
    }
    
    
    
}
	